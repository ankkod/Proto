/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


var myapp= angular.module("mymodule",[]);
var mycontroller=function($scope){
    
var products=[
    {name:'IRON',startdate:'1-2-2016',enddate:'1-3-2016',comments:'best product in electronics',upvotes:0,downvotes:0,image:'iron.jpg'},  
    {name:'MOBILE VOUCHERS',startdate:'1-2-2016',enddate:'1-3-2016',comments:'best product in electronics',upvotes:0,downvotes:0,image:'iron.jpg'},  
    {name:'MOBILES',startdate:'1-2-2016',enddate:'1-3-2016',comments:'best product in electronics',upvotes:0,downvotes:0,image:'iron.jpg'},  
    {name:'WHEAT GRAINS',startdate:'1-2-2016',enddate:'1-3-2016',comments:'best product in electronics',upvotes:0,downvotes:0,image:'iron.jpg'},  
    {name:'PALAK',startdate:'1-2-2016',enddate:'1-3-2016',comments:'best product in electronics',upvotes:0,downvotes:0,image:'iron.jpg'}  
   
    
    
];

    
    
    
$scope.products=products;  

$scope.incrementupvotes=function(product){
    product.upvotes++;
};
$scope.incrementdownvotes=function(product){
    product.downvotes++;
};



};

myapp.controller("mycontroller",mycontroller);